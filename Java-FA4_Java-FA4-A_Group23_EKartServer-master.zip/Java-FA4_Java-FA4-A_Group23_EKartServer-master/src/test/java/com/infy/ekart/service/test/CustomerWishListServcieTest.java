package com.infy.ekart.service.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.CustomerWishListDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.entity.Customer;
import com.infy.ekart.entity.CustomerWishList;
import com.infy.ekart.entity.Product;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerRepository;
import com.infy.ekart.repository.CustomerWishListRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.service.CustomerWishListService;
import com.infy.ekart.service.CustomerWishListServiceImpl;

@SpringBootTest
public class CustomerWishListServcieTest {

	@Mock
	CustomerRepository customerRepository;

	@Mock
	ProductRepository productRepository;
	
	@Mock
	CustomerWishListRepository customerWishListRepository;
	
	@InjectMocks
	CustomerWishListService  customerWishListService=new CustomerWishListServiceImpl();
	
	@Test
	void getCustomerWishListsValidTest1() throws EKartException {
		Product p = new Product();
		p.setProductId(222);
		CustomerWishList wishList = new CustomerWishList();
		wishList.setProduct(p);
		List<CustomerWishList> customerWishList = new ArrayList<CustomerWishList>();
		customerWishList.add(wishList);
		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		customer.setCustomerWishLists(customerWishList);
		Optional<Customer> optionalCustomer = Optional.of(customer);

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(optionalCustomer);
		List<CustomerWishListDTO> returned = customerWishListService.getCustomerWishLists(customer.getEmailId());
		Assertions.assertEquals(customerWishList.size(),returned.size());
	}
	
	@Test
	void getCustomerWishListsInvalidTest1() throws EKartException {

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(Optional.empty());
		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerWishListService.getCustomerWishLists("tom@infosys.com"));
		Assertions.assertEquals("Service.CUSTOMER_NOT_FOUND", exception.getMessage());
	}
	
	@Test
	void getCustomerWishListsInvalidTest2() throws EKartException {
		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		Optional<Customer> optionalCustomer = Optional.of(customer);

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(optionalCustomer);
		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerWishListService.getCustomerWishLists(customer.getEmailId()));
		Assertions.assertEquals("CustomerWishListService.NO_PRODUCT_ADDED_TO_WISHLIST", exception.getMessage());
	}
	
	@Test
	void addProductToWishListValidTest1() throws EKartException {

		Product product = new Product();
		product.setProductId(112);
		
		ProductDTO productDTO = new ProductDTO();
		productDTO.setProductId(product.getProductId());
		
		CustomerWishListDTO wishListDTO = new CustomerWishListDTO();
		wishListDTO.setProduct(productDTO);
		
		Optional<Product> optionalproduct = Optional.of(product);
		
		Product product1 = new Product();
		product1.setProductId(222);
		
		CustomerWishList wishList1 = new CustomerWishList();
		wishList1.setProduct(product1);
		List<CustomerWishList> customerWishList = new ArrayList<CustomerWishList>();
		customerWishList.add(wishList1);

		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		customer.setCustomerWishLists(customerWishList);
		Optional<Customer> optionalCustomer = Optional.of(customer);

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(optionalCustomer);

		Mockito.when(productRepository.findById(112)).thenReturn(optionalproduct);

		Assertions.assertDoesNotThrow(() -> customerWishListService.addProductToWishList("tom@infosys.com", wishListDTO));
	}
	
	
	@Test
	void addProductToWishListInvalidTest1() throws EKartException {

		Product product = new Product();
		product.setProductId(112);
		CustomerWishListDTO wishListDTO = new CustomerWishListDTO();
		ProductDTO productDTO = new ProductDTO();
		productDTO.setProductId(product.getProductId());
		wishListDTO.setProduct(productDTO);

		Product product1 = new Product();
		product1.setProductId(112);
		CustomerWishList wishList = new CustomerWishList();
		wishList.setProduct(product1);
		List<CustomerWishList> customerWishLists = new ArrayList<CustomerWishList>();
		customerWishLists.add(wishList);
		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		customer.setCustomerWishLists(customerWishLists);

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(Optional.empty());


		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerWishListService.addProductToWishList("tom@infosys.com", wishListDTO));
		Assertions.assertEquals("Service.CUSTOMER_NOT_FOUND", exception.getMessage());

	}
	
	@Test
	void deleteProductFromWishListValidTest1() throws EKartException {

		CustomerWishList wishList = new CustomerWishList();
		wishList.setWishListId(1001);
		Optional<CustomerWishList> optionalWishList = Optional.of(wishList);

		List<CustomerWishList> customerWishList = new ArrayList<CustomerWishList>();
		customerWishList.add(wishList);
		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		customer.setCustomerWishLists(customerWishList);
		Optional<Customer> optionalCustomer = Optional.of(customer);

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(optionalCustomer);

		Mockito.when(customerWishListRepository.findById(1001)).thenReturn(optionalWishList);

		Assertions.assertDoesNotThrow(() -> customerWishListService.deleteProductFromWishList("tom@infosys.com", 1001));
	}
	
	@Test
	void deleteProductFromWishListInValidTest1() throws EKartException {

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(Optional.empty());

		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerWishListService.deleteProductFromWishList("tom@infosys.com", 1001));
		Assertions.assertEquals("Service.CUSTOMER_NOT_FOUND", exception.getMessage());
	}
	
	@Test
	 void deleteProductFromWishListInValidTest2() throws EKartException {
		CustomerWishList wishList = new CustomerWishList();
		wishList.setWishListId(1001);
		List<CustomerWishList> customerWishList = new ArrayList<CustomerWishList>();
		customerWishList.add(wishList);
		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		customer.setCustomerWishLists(customerWishList);
		Optional<Customer> optionalCustomer = Optional.of(customer);

		Mockito.when(customerRepository.findById("tom@infosys.com")).thenReturn(optionalCustomer);

		Mockito.when(customerWishListRepository.findById(1001)).thenReturn(Optional.empty());

		EKartException exception = Assertions.assertThrows(EKartException.class,
				() -> customerWishListService.deleteProductFromWishList("tom@infosys.com", 1001));
		Assertions.assertEquals("Service.WISHLIST_NOT_FOUND", exception.getMessage());
	}
}