package com.infy.ekart.repository.test;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.infy.ekart.entity.CustomerWishList;
import com.infy.ekart.repository.CustomerWishListRepository;

@DataJpaTest
public class CustomerWishListRepositoryTest {

	@Autowired
	private CustomerWishListRepository customerWishListRepository;

	private CustomerWishList customerWishList;
	
	@BeforeEach
	public void setup() {
		customerWishList = new CustomerWishList();
		customerWishList.setWishListId(1);  
	}
	
	@Test
	void findByIdCustomerWishListsValid() {
		customerWishListRepository.save(customerWishList);
		Optional<CustomerWishList> optionalCustomerWishList = customerWishListRepository.findById(1);
		Assertions.assertTrue(optionalCustomerWishList.isPresent());
	}

	@Test
	void findByIdCustomerWishListsInvalid() {
		Optional<CustomerWishList> optionalCustomerCart = customerWishListRepository.findById(2);
		Assertions.assertTrue(optionalCustomerCart.isEmpty());
	}

	@Test
	void deleteCustomerWishListsValid() {
		customerWishListRepository.save(customerWishList);
		customerWishListRepository.delete(customerWishList);
		Optional<CustomerWishList> optionalCustomerCart = customerWishListRepository.findById(1);
		Assertions.assertTrue(optionalCustomerCart.isEmpty());
	}
}


