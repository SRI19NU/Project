package com.infy.ekart.service.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.entity.CustomerWishList;
import com.infy.ekart.entity.Product;
import com.infy.ekart.entity.ProductCategory;
import com.infy.ekart.entity.Seller;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerWishListRepository;
import com.infy.ekart.repository.ProductCategoryRepository;
import com.infy.ekart.repository.ProductRepository;
import com.infy.ekart.repository.SellerRepository;
import com.infy.ekart.service.SellerProductService;
import com.infy.ekart.service.SellerProductServiceImpl;

@SpringBootTest
class SellerProductServiceTest {
	

	@Mock
	private ProductCategoryRepository productCategoryRepository;
	
	@Mock
	private ProductRepository productRepository;
	
	@Mock
	private SellerRepository sellerRepository;
	@Mock
	CustomerWishListRepository customerWishListRepository;
	
	@InjectMocks
	private SellerProductService sellerProductService = new SellerProductServiceImpl();
	
	// testing addNewProduct() method
	@Test
	void addNewProductValidTest() throws EKartException{
		ProductDTO productDTO=new ProductDTO();
		productDTO.setBrand("Motobot");
		productDTO.setCategory("Electronics - Mobile");
		productDTO.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		productDTO.setDiscount(5.0);
		productDTO.setName("Xpress");
		productDTO.setPrice(16000.0);
		productDTO.setProductId(1001);
		productDTO.setQuantity(150);
		Product product=new Product();
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setDiscount(5.0);
		product.setName("Xpress");
		product.setPrice(16000.0);
		product.setProductId(1001);
		product.setQuantity(150);
		Mockito.when(productRepository.save(Mockito.any())).thenReturn(product);
		Assertions.assertEquals(productDTO.getProductId(), sellerProductService.addNewProduct(productDTO));
	}
	
	
	// testing modifyProductDetails() method
	@Test
	void modifyProductDetailsValidTest() throws EKartException{
		ProductDTO productDTO=new ProductDTO();
		productDTO.setBrand("Motobot");
		productDTO.setCategory("Electronics - Mobile");
		productDTO.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		productDTO.setDiscount(5.0);
		productDTO.setName("Xpress");
		productDTO.setPrice(16000.0);
		productDTO.setProductId(1001);
		productDTO.setQuantity(150);
		
		Product product=new Product();
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setDescription("Smart phone with (13+13) MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setDiscount(5.0);
		product.setName("Xpress");
		product.setPrice(16000.0);
		product.setProductId(1001);
		product.setQuantity(150);
		Mockito.when(productRepository.findById(Mockito.any())).thenReturn(Optional.of(product));
		Assertions.assertEquals(productDTO, sellerProductService.modifyProductDetails(productDTO));
	}

	// testing getProductCategoryList() method
	@Test
	void getProductCategoryListValidTest() throws EKartException{
		List<ProductCategory> productCategories = new ArrayList<ProductCategory>();
		ProductCategory productCategory = new ProductCategory();
		productCategory.setCategory("Electronics - Mobile");
		productCategories.add(productCategory);
		Mockito.when(productCategoryRepository.findAll()).thenReturn(productCategories);
		Assertions.assertNotNull(sellerProductService.getProductCategoryList());
	}
	
	// testing removeProduct() method
	@Test
	void removeProductValidTest() throws EKartException{
		ProductDTO productDTO=new ProductDTO();
		productDTO.setProductId(1);
		
		Seller seller= new Seller();
		seller.setEmailId("john@gmail.com");
		Optional<Seller> optionalSeller=Optional.of(seller);
		
		Mockito.when(sellerRepository.findById(productDTO.getSellerEmailId())).thenReturn(optionalSeller);
		Assertions.assertNotNull(sellerProductService.removeProduct(productDTO));
	}
	
	// testing SELLER_NOT_FOUND exception
	@Test
	void remvoeProductInvalidTest() {
		ProductDTO productDTO=new ProductDTO();
		productDTO.setProductId(1);
		Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(new Seller()));
		EKartException eKartException = Assertions.assertThrows(EKartException.class,
				() -> sellerProductService.removeProduct(productDTO));

		Assertions.assertEquals("Service.SELLER_NOT_FOUND", eKartException.getMessage());
	}
	
	//TESTING FOR PRODUCT IN WISHLIST
	@Test
	public  void getProductInWishlistValidTest()  {
		
		Product product1 = new Product();
		product1.setProductId(1001);
		
		CustomerWishList customerWishlist1 =new CustomerWishList();
		customerWishlist1.setProduct(product1);
		
		List<CustomerWishList> listCustomerWishlist = new ArrayList<>();
		listCustomerWishlist.add(customerWishlist1);
		Iterable<CustomerWishList> iterableCustomerWishlist = listCustomerWishlist;
		
		List<Product> productList = new ArrayList<>();
		productList.add(product1);
        ProductDTO pDTO = new ProductDTO();
        pDTO.setProductId(product1.getProductId());
        Seller seller = new Seller();
        seller.setEmailId("jack@infosys.com");
        seller.setProduct(productList);
        Optional<Seller> sellerOptional = Optional.of(seller);
        Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(sellerOptional);
        Mockito.when(customerWishListRepository.findAll()).thenReturn(iterableCustomerWishlist);
		Mockito.when(sellerRepository.findProductByEmailId(Mockito.anyString())).thenReturn(productList);
		Assertions.assertDoesNotThrow(()-> sellerProductService.getCustomerInterests(seller.getEmailId()));
	}
	//seller not found
		@Test
		void getCustomerInterestsInvalidTest1() {
			
	        Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
			EKartException e =Assertions.assertThrows(EKartException.class, () ->sellerProductService.getCustomerInterests("jack@infosys.com"));
			Assertions.assertEquals("Service.SELLER_NOT_FOUND",e.getMessage());
		}
	
	
		//TESTING FOR INVALID SELLER
	@Test
	public  void getProductInWishlistInValidTest1() throws EKartException {
		
		Product product1 = new Product();
		product1.setProductId(1001);		
		Product product2 = new Product();
		product2.setProductId(2011);
		CustomerWishList customerWishlist1 =new CustomerWishList();
		customerWishlist1.setProduct(product1);
		CustomerWishList customerWishlist2 =new CustomerWishList();
		customerWishlist2.setProduct(product2);
		
		List<CustomerWishList>listCustomerWishlist = new ArrayList<CustomerWishList>();
		
		listCustomerWishlist.add(customerWishlist1);
		listCustomerWishlist.add(customerWishlist2);
		
		Iterable<CustomerWishList> iterableCustomerWishlist = listCustomerWishlist;
		
		List<Product> productList = new ArrayList<>();
		productList.add(product1);
		productList.add(product2);
	    ProductDTO pDTO = new ProductDTO();
	    pDTO.setProductId(product1.getProductId());
	    Seller seller = new Seller();
	    seller.setEmailId("jack@infosys.com");
	    seller.setProduct(productList);
	   
	    Mockito.when(customerWishListRepository.findAll()).thenReturn(iterableCustomerWishlist);
		Mockito.when(sellerRepository.findById("jack@infosys.com")).thenReturn(Optional.empty());
		EKartException e =Assertions.assertThrows(EKartException.class, () ->sellerProductService.getCustomerInterests("jack@infosys.com"));
		Assertions.assertEquals("Service.SELLER_NOT_FOUND",e.getMessage());

	}
//	TESTING FOR NO PRODUCT ADDED IN THE WISHLIST
	@Test
	public  void getProductInWishlistInValidTest2()  {
		
		Product product1 = new Product();
		product1.setProductId(1001);	
		
		List<Product> productList = new ArrayList<>();		
		productList.add(product1);	
		
		 Seller seller = new Seller();
	     seller.setEmailId("brad@infosys.com");
	     seller.setProduct(productList);
	     Optional<Seller> oSeller =Optional.of(seller);

		CustomerWishList customerWishlist1 =new CustomerWishList();
		customerWishlist1.setProduct(product1);		
		List<CustomerWishList> listCustomerWishlist = new ArrayList<>();
		listCustomerWishlist.add(customerWishlist1);
		
		Iterable<CustomerWishList> iterableCustomerWishlist = new ArrayList<>();
		
	    Mockito.when(sellerRepository.findProductByEmailId(Mockito.anyString())).thenReturn(productList);
		Mockito.when(sellerRepository.findById(Mockito.anyString())).thenReturn(oSeller);
	    Mockito.when(customerWishListRepository.findAll()).thenReturn(iterableCustomerWishlist);

		
		EKartException e =Assertions.assertThrows(EKartException.class, () ->sellerProductService.getCustomerInterests("brad@infosys.com"));
		Assertions.assertEquals("CustomerInterests.NO_CUSTOMER_INTERESTS_FOUND",e.getMessage());
	}

}

