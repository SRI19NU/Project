package com.infy.ekart.dto;

import com.infy.ekart.entity.Product;

public class CustomerInterestsDTO {
	private Product product;
	private Integer noOfCustomers;
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Integer getNoOfCustomers() {
		return noOfCustomers;
	}
	public void setNoOfCustomers(Integer noOfCustomers) {
		this.noOfCustomers = noOfCustomers;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((product.getProductId() == null) ? 0 : product.getProductId().hashCode());
		 return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerInterestsDTO other = (CustomerInterestsDTO) obj;
		if (product.getProductId() == null) {
			if (other.product.getProductId() != null)
				return false;
		} else if (!product.getProductId().equals(other.product.getProductId()))
			return false;
		return true;
	}
	

}
