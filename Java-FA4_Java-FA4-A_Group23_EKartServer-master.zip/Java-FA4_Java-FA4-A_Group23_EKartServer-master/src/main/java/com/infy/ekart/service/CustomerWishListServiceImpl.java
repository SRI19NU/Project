package com.infy.ekart.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.dto.CustomerWishListDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.entity.Customer;
import com.infy.ekart.entity.CustomerWishList;
import com.infy.ekart.entity.Product;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerRepository;
import com.infy.ekart.repository.CustomerWishListRepository;
import com.infy.ekart.repository.ProductRepository;

@Service(value = "customerWishListService")
@Transactional
public class CustomerWishListServiceImpl implements CustomerWishListService{

	@Autowired
	private CustomerWishListRepository customerWishListRepository;

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public 	void addProductToWishList(String customerEmailId, CustomerWishListDTO customerWishListDTO) throws EKartException{
		Optional<Customer> optionalCustomer = customerRepository.findById(customerEmailId.toLowerCase());
		Customer customer = optionalCustomer
				.orElseThrow(() -> new EKartException("Service.CUSTOMER_NOT_FOUND"));

		List<CustomerWishList> wishLists = customer.getCustomerWishLists();

		for (CustomerWishList customerWishList : wishLists) {
			if (customerWishList.getProduct().getProductId().equals(customerWishListDTO.getProduct().getProductId()))
				throw new EKartException("CustomerWishListService.PRODUCT_PRESENT_IN_CART");
		}
		
		Optional<Product> optionalProduct = productRepository.findById(customerWishListDTO.getProduct().getProductId());
		Product product = optionalProduct
				.orElseThrow(() -> new EKartException("Service.PRODUCT_NOT_FOUND"));

		
		CustomerWishList wishList=new CustomerWishList();
		
		wishList.setProduct(product);
		wishList.setAddedDate(LocalDateTime.now());
		wishLists.add(wishList);
		customer.setCustomerWishLists(wishLists);
		customerRepository.save(customer);
		
	}

	@Override
	public List<CustomerWishListDTO> getCustomerWishLists(String customerEmailId) throws EKartException {
		
		Optional<Customer> optionalCustomer = customerRepository.findById(customerEmailId.toLowerCase());
		Customer customer = optionalCustomer
				.orElseThrow(() -> new EKartException("Service.CUSTOMER_NOT_FOUND"));

		List<CustomerWishList> wishLists = customer.getCustomerWishLists();
		
		if (wishLists == null || wishLists.isEmpty()) {
			throw new EKartException("CustomerWishListService.NO_PRODUCT_ADDED_TO_WISHLIST");
		}

		List<CustomerWishListDTO> listCustomerWishList = new ArrayList<>();
		wishLists.forEach(customerWishList -> {
			CustomerWishListDTO wishList = new CustomerWishListDTO();
			wishList.setWishListId(customerWishList.getWishListId());
			wishList.setAddedDate(customerWishList.getAddedDate());

			Product product = customerWishList.getProduct();

			ProductDTO productDTO = new ProductDTO();
			productDTO.setBrand(product.getBrand());
			productDTO.setCategory(product.getCategory());
			productDTO.setDescription(product.getDescription());
			productDTO.setDiscount(product.getDiscount());
			productDTO.setName(product.getName());
			productDTO.setPrice(product.getPrice());
			productDTO.setProductId(product.getProductId());
			
			wishList.setProduct(productDTO);

			listCustomerWishList.add(wishList);

		});
		return listCustomerWishList;
	}

	@Override
	public void deleteProductFromWishList(String customerEmailId, Integer wishListId) throws EKartException {
		
		Optional<Customer> optionalCustomer = customerRepository.findById(customerEmailId.toLowerCase());
		Customer customer = optionalCustomer
				.orElseThrow(() -> new EKartException("Service.CUSTOMER_NOT_FOUND"));		

		List<CustomerWishList> wishLists = customer.getCustomerWishLists();
		CustomerWishList wishListToRemove = null;

		for (CustomerWishList customerWishList : wishLists) {
			if (wishListId.equals(customerWishList.getWishListId())) {
				wishListToRemove = customerWishList;
				break;
			}
		}
		wishLists.remove(wishListToRemove);
		customer.setCustomerWishLists(wishLists);
		
		Optional<CustomerWishList> optionalWishList = customerWishListRepository.findById(wishListId);
		CustomerWishList wishList = optionalWishList.orElseThrow(() -> new EKartException("Service.WISHLIST_NOT_FOUND"));

		customerWishListRepository.delete(wishList);

	}

}