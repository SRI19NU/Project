package com.infy.ekart.service;

import java.util.List;

import com.infy.ekart.dto.CustomerWishListDTO;
import com.infy.ekart.exception.EKartException;

public interface CustomerWishListService {
	
	void addProductToWishList(String customerEmailId, CustomerWishListDTO customerWishList) throws EKartException;
	List<CustomerWishListDTO> getCustomerWishLists(String customerEmailId) throws EKartException;
	void deleteProductFromWishList(String customerEmailId, Integer wishListId) throws EKartException;
	
}