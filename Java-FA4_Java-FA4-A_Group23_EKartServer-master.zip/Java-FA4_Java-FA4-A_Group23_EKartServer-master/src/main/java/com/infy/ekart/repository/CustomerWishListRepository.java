 package com.infy.ekart.repository;


import org.springframework.data.repository.CrudRepository;

import com.infy.ekart.entity.CustomerWishList;

public interface CustomerWishListRepository extends CrudRepository<CustomerWishList,Integer>{
	
	
}