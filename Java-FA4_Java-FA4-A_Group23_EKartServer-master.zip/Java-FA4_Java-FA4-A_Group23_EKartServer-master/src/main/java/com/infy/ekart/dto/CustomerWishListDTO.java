package com.infy.ekart.dto;

import java.time.LocalDateTime;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CustomerWishListDTO { 
	
	@NotNull(message="{wishList.wishListId.absent}")
	private Integer wishListId;
	
	@Valid
	private ProductDTO product;
	
	@NotNull
	@PastOrPresent(message="{wishList.invalid.addedDate}")
	@JsonFormat(pattern="dd-MMM-yyyy HH:mm:ss")
	private LocalDateTime addedDate;
	
	@Pattern(regexp="[a-zA-Z0-9._]+[a-zA-Z]{2}\\.[A-Za-z][a-zA-Z.]+",message="{invalid.email.format}")
	private String emailId;

	private String errorMessage;
	private String successMessage;
	
	public Integer getWishListId() {
		return wishListId;
	}
	public void setWishListId(Integer wishListId) {
		this.wishListId = wishListId;
	}
	public ProductDTO getProduct() {
		return product;
	}
	public void setProduct(ProductDTO product) {
		this.product = product;
	}
	public LocalDateTime getAddedDate() {
		return addedDate;
	}
	public void setAddedDate(LocalDateTime addedDate) {
		this.addedDate = addedDate;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getSuccessMessage() {
		return successMessage;
	}
	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}
	
} 