package com.infy.ekart.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="EK_CUSTOMER_WISHLIST")
public class CustomerWishList {
	
	@Id
	@Column(name="WISHLIST_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer wishListId;
	
	@OneToOne(cascade=CascadeType.DETACH)
	@JoinColumn(name="PRODUCT_ID")
	private Product product;
	
	@Column(name="PRODUCT_ADDED_DATE")
	private LocalDateTime addedDate;
	
	@Column(name="CUSTOMER_EMAIL_ID")
	private String emailId;
	
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Integer getWishListId() {
		return wishListId;
	}
	public void setWishListId(Integer wishListId) {
		this.wishListId = wishListId;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public LocalDateTime getAddedDate() {
		return addedDate;
	}
	public void setAddedDate(LocalDateTime addedDate) {
		this.addedDate = addedDate;
	}	
}