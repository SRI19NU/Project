package com.infy.ekart.api;

import java.util.List;

import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infy.ekart.dto.CustomerWishListDTO;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.service.CustomerWishListService;

@CrossOrigin
@RestController
@RequestMapping(value = "/customerWishlist-api")
@Validated
public class CustomerWishListAPI {
	@Autowired
	private Environment environment;
	
	@Autowired
	private CustomerWishListService customerWishListService;

	
	@PostMapping(value = "/customerWishlists/{customerEmailId:.+}/products")
	public ResponseEntity<String> addProductToWishList(@RequestBody CustomerWishListDTO customerWishListDTO,
			@Pattern(regexp = "[a-zA-Z0-9._]+@[a-zA-Z]{2,}\\.[a-zA-Z][a-zA-Z.]+") @PathVariable("customerEmailId") String customerEmailId)
			throws EKartException {
		customerWishListService.addProductToWishList(customerEmailId, customerWishListDTO);
		String message = environment.getProperty("CustomerWishListAPI.PRODUCT_ADDED_TO_WISHLIST");
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
	
	@GetMapping(value = "/customers/{customerEmailId:.+}/customerWishlists")
	public ResponseEntity<List<CustomerWishListDTO>> getCustomerWishList(
			@Pattern(regexp = "[a-zA-Z0-9._]+@[a-zA-Z]{2,}\\.[a-zA-Z][a-zA-Z.]+", message = "{invalid.email.format}") @PathVariable("customerEmailId") String customerEmailId)
			throws EKartException {
		List<CustomerWishListDTO> list = null;
		list = customerWishListService.getCustomerWishLists(customerEmailId);
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	

	@DeleteMapping(value = "/customers/{customerEmailId:.+}/customerWishlists/{customerWishListId}/products")
	public ResponseEntity<String> deleteProductFromWishList(
			@Pattern(regexp = "[a-zA-Z0-9._]+@[a-zA-Z]{2,}\\.[a-zA-Z][a-zA-Z.]+", message = "{invalid.email.format}") @PathVariable("customerEmailId") String customerEmailId,
			@PathVariable String customerWishListId) throws EKartException {
		customerWishListService.deleteProductFromWishList(customerEmailId, Integer.parseInt(customerWishListId));
		String message = environment.getProperty("CustomerWishListAPI.PRODUCT_DELETED_FROM_WISHLIST_SUCCESS");
		return new ResponseEntity<>(message, HttpStatus.OK);
	}
}