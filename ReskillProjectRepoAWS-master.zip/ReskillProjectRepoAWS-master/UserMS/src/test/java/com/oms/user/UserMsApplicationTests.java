package com.oms.user;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class UserMsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
