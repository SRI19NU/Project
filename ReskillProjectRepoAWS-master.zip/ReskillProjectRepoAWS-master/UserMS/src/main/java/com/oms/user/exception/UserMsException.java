package com.oms.user.exception;

@SuppressWarnings("serial")
public class UserMsException extends Exception {
	
	public UserMsException(String message) {
		super(message);
	}

}
