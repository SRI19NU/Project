package com.oms.order;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class OrderMsApplicationTests {

	@Test
	public void contextLoads() {
	}

}
