package com.oms.order.exception;


@SuppressWarnings("serial")
public class OrderMsException extends Exception{
	public OrderMsException(String message) {
		super(message);
	}
}
