package com.oms.order.utility;

public enum OrderStatus {
	ORDER_PLACED,
	PACKING,
	DISPATCHED,
	DELIVERED
}
