package com.oms.product.exception;

@SuppressWarnings("serial")
public class ProductMsException extends Exception {
	
	public ProductMsException(String message) {
		super(message);
	}

}
